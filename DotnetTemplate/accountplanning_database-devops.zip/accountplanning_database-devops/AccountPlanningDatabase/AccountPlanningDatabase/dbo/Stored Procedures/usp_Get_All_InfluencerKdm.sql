﻿CREATE PROCEDURE dbo.usp_Get_All_InfluencerKdm
AS
BEGIN
	SELECT 
		Id,
		Name 
	FROM InfluencerKdm
END








